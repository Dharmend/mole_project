 $(document).ready(function(){
    
$('.bxslider').bxSlider({
  minSlides: 5,
  maxSlides: 6,
  slideWidth: 140,
  slideMargin: 7
});
  });